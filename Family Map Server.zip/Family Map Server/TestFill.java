package test;

import service.FillService;
import result.FillResult;
import request.FillRequest;
import model.*;

import org.junit.*;
import static org.junit.Assert.*;

public class TestFill {
    FillService service;
    FillRequest request;
    FillResult testResult;

    @Before
    public void setUp() throws Exception {
        service = new FillService();
        request = new FillRequest();
        testResult = new FillResult();
        testResult.setMessage("Successfully added 1 users, 1 persons, and 1 events to the database.");
        User bestUser = new User("cleverUsername", "1234", "myEmail@gmail.com", "Johnny", "Shiney", "M", "asdf1234");
        User[] users = {bestUser};
        Person bestPerson = new Person("asdf1234", "redRum", "Johnny", "Shiney", "M", "Father", "Mother", "axeGirl");
        Person[] persons = {bestPerson};
        Event bestEvent = new Event("1243", "Son", "aPerson", "12", "21", "United Kingdom", "London", "Mystery", "2019");
        Event[] events = {bestEvent};
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void fillPass() throws Exception {
        //FillResult result = service.fill(request);

        //assertNotNull(result);
        
        //assertEquals(testResult.resultMsg(), result.resultMsg());
    }

    @Test
    public void fillFail() throws Exception {
        //FillResult result = service.fill(request);

        //assertNotNull(result);
        
       //assertEquals(testResult.resultMsg(), result.resultMsg());
    }
}
