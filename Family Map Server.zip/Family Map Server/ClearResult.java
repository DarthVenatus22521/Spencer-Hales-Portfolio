package result;

/**
 *Object to be returned from clear service with the result of the action
 */
public class ClearResult {    
    
    String message;

    /**
     *The toString method of this class, returns success or not
     */
    public String resultMsg() {
        return message;
    }

    public void setMessage(String s) {
        message = s;
    }
}
