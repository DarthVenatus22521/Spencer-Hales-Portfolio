package test;

import java.util.*;
import java.lang.*;
import java.io.*;

public class TestJUnit {
	public static void main(String[] args) throws Exception {
		TestUserDAO uTest = new TestUserDAO();
        TestPersonDAO pTest = new TestPersonDAO();
        TestAuthDAO aTest = new TestAuthDAO();
        TestEventDAO eTest = new TestEventDAO();
        TestLoad loadTest = new TestLoad();
        TestClear clearTest = new TestClear();
        TestRegister registerTest = new TestRegister();
        TestLogin loginTest = new TestLogin();
        TestPersonID personIDTest = new TestPersonID();
        TestEventID eventIDTest = new TestEventID();
        TestPerson personTest = new TestPerson();
        TestEvent eventTest = new TestEvent();
        try {
            uTest.setUp();
            uTest.insertPass();
            uTest.insertFail();
            uTest.findPass();
            uTest.findFail();
            uTest.clearPass();
            uTest.clearFail();
            uTest.tearDown();

            pTest.setUp();
            pTest.insertPass();
            pTest.insertFail();
            pTest.findPass();
            pTest.findFail();
            pTest.clearPass();
            pTest.clearFail();
            pTest.tearDown();

            aTest.setUp();
            aTest.insertPass();
            aTest.insertFail();
            aTest.findPass();
            aTest.findFail();
            aTest.clearPass();
            aTest.clearFail();
            aTest.tearDown();

            eTest.setUp();
            eTest.insertPass();
            eTest.insertFail();
            eTest.findPass();
            eTest.findFail();
            eTest.clearPass();
            eTest.clearFail();
            eTest.tearDown();

            loadTest.setUp();
            loadTest.loadPass();
            loadTest.tearDown();

            clearTest.setUp();
            clearTest.clearPass();
            clearTest.twoClearPass();
            clearTest.tearDown();

            registerTest.setUp();
            registerTest.registerPass();
            registerTest.registerFail();
            registerTest.tearDown();

            loginTest.setUp();
            loginTest.loginPass();
            loginTest.loginFail();
            loginTest.tearDown();

            personIDTest.setUp();
            personIDTest.findIDPass();
            personIDTest.findIDFail();
            personIDTest.tearDown();

            eventIDTest.setUp();
            eventIDTest.findIDPass();
            eventIDTest.findIDFail();
            eventIDTest.tearDown();

            personTest.setUp();
            personTest.findPass();
            personTest.findFail();
            personTest.tearDown();

            eventTest.setUp();
            eventTest.findPass();
            eventTest.findFail();
            eventTest.tearDown();
        }
        catch (Exception e) {	
            e.printStackTrace();	    
        }
    }
}
