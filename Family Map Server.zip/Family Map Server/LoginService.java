package service;

import java.sql.Connection;
import request.LoginRequest;
import result.LoginResult;
import DAO.*;
import model.*;

/**
 *Service class to handle login requests
 */
public class LoginService {
    /**
    *Method to login a user
    *Passes in a LoginRequest object with login info
    *returns a LoginResult detailing what happened
    */
    public LoginResult login(LoginRequest r) {
        User user = null;
        Database db = new Database();
        try {        
            db.createTables();
            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            
            user = uDao.find(r.getUsername());  
            LoginResult result = new LoginResult();
            if (user == null) {
                throw new DataAccessException("Invalid username or password");
            }
            else if (!user.getPassword().equals(r.getPassword())) {
                throw new DataAccessException("Invalid username or password");
            }
            RandomString randStr = new RandomString();
            String token = randStr.generate();
            AuthDAO aDAO = new AuthDAO(conn);
            Auth auth = new Auth(token, user.getUsername(), "aTime", user.getPersonID());
            aDAO.createAuth(auth);
            result.setAuthToken(token);
            result.setUsername(user.getUsername());
            result.setPersonID(user.getPersonID());
            db.closeConnection(true);
            return result;
        }
        catch (DataAccessException d) {
            try{
                db.closeConnection(false);
            }   
            catch (DataAccessException e) {
                System.out.println(e.toString());
            }
            LoginResult failResult = new LoginResult();
            failResult.isFail(d.toString());
            return failResult;
        }
    }
}
