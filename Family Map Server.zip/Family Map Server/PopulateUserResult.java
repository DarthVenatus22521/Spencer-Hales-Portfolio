package result;

/**
 *Object to be returned from Fill service with the result of the action
 */
public class PopulateUserResult {
    
    String message;

    /**
     *The toString method of this class
     */
    public String resultMsg() {
        return message;
    }

    public void setMessage(String msg) {
        message = msg;
    }
}
