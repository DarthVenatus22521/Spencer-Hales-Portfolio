package test;

import service.*;
import result.*;
import request.*;
import model.*;

import org.junit.*;
import static org.junit.Assert.*;

public class TestLogin {
    LoginService service;
    LoginRequest request;

    @Before
    public void setUp() throws Exception {
        ClearService clearService = new ClearService();
        ClearResult clearResult = clearService.clear();
        service = new LoginService();
        request = new LoginRequest("username", "password");
        RegisterRequest regRequest = new RegisterRequest("username", "password", "anEmail", "firstname", "lastname", "m");
        RegisterService regService = new RegisterService();
        RegisterResult regResult = regService.register(regRequest);
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void loginPass() throws Exception {
        LoginResult result = service.login(request);

        assertNotNull(result);
        
        assertEquals(true, result.wasFail());
    }

    @Test
    public void loginFail() throws Exception {
        LoginRequest failRequest = new LoginRequest("user", "pass");

        LoginResult result = service.login(failRequest);

        assertNotNull(result);
        
        assertEquals(false, result.wasFail());
    }
}
