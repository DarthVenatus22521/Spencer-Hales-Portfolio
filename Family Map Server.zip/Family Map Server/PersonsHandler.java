package handle;

import service.PersonService;
import result.PersonResult;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import java.net.HttpURLConnection;
import com.google.gson.*;
import java.net.*;

public class PersonsHandler implements HttpHandler{
        
    @Override
    public void handle(HttpExchange exchange) throws IOException {
        try {
            boolean success = false;
            Gson gson = new Gson();
            if (exchange.getRequestMethod().toLowerCase().equals("get")) {
                Headers reqHeaders = exchange.getRequestHeaders();
                if (reqHeaders.containsKey("Authorization")) {
                    String authToken = reqHeaders.getFirst("Authorization");

                    PersonService personService = new PersonService();
                    PersonResult personResult = personService.findPeople(authToken);
                    String response = gson.toJson(personResult);

                    exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK,0);
                    OutputStream respBody = exchange.getResponseBody();
                    writeString(response, respBody);
                    respBody.close();
                    exchange.getResponseBody().close();
                    success = true;
                }
            }
            if (!success) {
                exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);
                exchange.getResponseBody().close();
            }
        }
        catch(IOException e) {
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_SERVER_ERROR, 0);
            exchange.getResponseBody().close();
            System.out.println(e.toString());
            e.printStackTrace();
        }
    }

    private void writeString(String str, OutputStream os) throws IOException {
        OutputStreamWriter osw = new OutputStreamWriter(os);
        osw.write(str);
        osw.flush();
    }
}
