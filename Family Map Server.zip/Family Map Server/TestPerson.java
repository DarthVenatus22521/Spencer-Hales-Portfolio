package test;

import java.util.*;
import model.*;
import DAO.*;
import service.*;
import result.*;
import request.*;

import java.sql.Connection;

import org.junit.*;
import static org.junit.Assert.*;

public class TestPerson {
    Database db;
    Person bestPerson;
    Person aPerson;
    Person fury;
    PersonService service;

    @Before
    public void setUp() throws Exception {
        db = new Database();
        service = new PersonService();
        bestPerson = new Person("asdf1234", "user", "Johnny", "Shiney", "M", "Father", "Mother", "axeGirl");
        aPerson = new Person("comp1982", "user", "Kevin", "Flynn", "M", "Kevin", "Mummy", "robot");
        fury = new Person("B@dA$$MoFo", "user", "Sam", "Jackson", "M", "aDad", "aMom", "Girl");
        Auth bestAuth = new Auth("auth", "user", "7:00", "asdf1234");
        db.createTables();
            try {
            Connection conn = db.openConnection();
            PersonDAO pDao = new PersonDAO(conn);
            pDao.createPerson(aPerson);
            pDao.createPerson(fury);
            pDao.createPerson(bestPerson);
            AuthDAO aDao = new AuthDAO(conn);
            aDao.createAuth(bestAuth);
            db.closeConnection(true);
        } catch (DataAccessException e) {
            db.closeConnection(false);
        }
    }

    @After
    public void tearDown() throws Exception {
        db.clearTables();
    }

    @Test
    public void findPass() throws Exception {
        PersonResult result = service.findPeople("auth");

        assertNotNull(result);
        assertEquals(3, result.getNumPeople());
    }

    @Test
    public void findFail() throws Exception {
        PersonResult result = service.findPeople("authkjhg");

        assertNull(result);
    }
}
