package request;

/**
 *Class to contain information needed to start the Fill service
 */
public class FillRequest {

    String username;
    int generations = 4;

    /**
     *Method to return the needed information for Fill
     */    
    public String toString() {
        return null;
    }

    public String getUsername() {
        return username;
    }

    public int getGenerations() {
        return generations;
    }

    public void setUsername(String s) {
        username = s;
    }

    public void setGenerations(int i) {
        generations = i;
    }
}
