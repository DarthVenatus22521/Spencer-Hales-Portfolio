package server;

import handle.*;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;

public class Server {

    private HttpServer server;

    private static void startServer(int port) throws IOException{
        InetSocketAddress serverAddress = new InetSocketAddress(port);
        HttpServer server = HttpServer.create(serverAddress, 10);
        registerHandlers(server);
        server.start();
        System.out.println("FamilyMapServer listening on port " + port);
    }

    private static void registerHandlers(HttpServer server) {
        server.createContext("/", new DefaultHandler());
        server.createContext("/user/register", new RegisterHandler());
        server.createContext("/user/login", new LoginHandler());
        server.createContext("/clear", new ClearHandler());
        server.createContext("/fill", new FillHandler());
        server.createContext("/load", new LoadHandler());
        server.createContext("/person", new PersonsHandler());
        server.createContext("/person/", new PersonIDHandler());
        server.createContext("/event", new EventsHandler());
        server.createContext("/event/", new EventIDHandler());
    }

    public static void main(String[] args) {
        int port;        
        if (args.length < 1) {
            port = 8080;
        }
        else {
            port = Integer.parseInt(args[0]);
        }
        try {
            startServer(port);
        }
        catch(IOException e) {
            e.printStackTrace();
            return;
        }
    }
}
