package test;

import model.*;
import DAO.*;
import service.*;
import result.*;
import request.*;

import java.sql.Connection;

import org.junit.*;
import static org.junit.Assert.*;

public class TestEventID {
    Database db;
    Event bestEvent;
    Event aEvent;
    Event fury;
    EventService service;

    @Before
    public void setUp() throws Exception {
        db = new Database();
        service = new EventService();
        bestEvent = new Event("1243", "Son", "aPerson", "12", "21", "United Kingdom", "London", "Mystery", "2019");
        aEvent = new Event("4321", "Daughter", "anID", "24", "42", "America", "Provo", "Party", "2018");
        fury = new Event("2319", "Child", "Shield", "15", "51", "America", "New York City", "Aliens", "2008");
        Auth bestAuth = new Auth("bestEvent", "Son", "7:00", "aPerson");
        db.createTables();
            try {
            Connection conn = db.openConnection();
            EventDAO eDao = new EventDAO(conn);
            eDao.createEvent(aEvent);
            eDao.createEvent(fury);
            eDao.createEvent(bestEvent);
            AuthDAO aDao = new AuthDAO(conn);
            aDao.createAuth(bestAuth);
            db.closeConnection(true);
        } catch (DataAccessException e) {
            db.closeConnection(false);
        }
    }

    @After
    public void tearDown() throws Exception {
        db.clearTables();
    }

    @Test
    public void findIDPass() throws Exception {
        Event e = bestEvent;
        String bestInfo = "eventID: " + e.getEventID() + "\ndescendant: " + e.getDescendant() + "\npersonID: " + e.getPersonID() +
                      "\nlatitude: " + e.getLatitude() + "\nlongitude: " + e.getLongitude() + "\ncountry: " + e.getCountry() + 
                      "\ncity: " + e.getCity() + "\neventType: " + e.getEventType() + "\nyear: " + e.getYear() + "\n\n";
        EventResult result = service.findSingleEvent("1243", "bestEvent");

        assertNotNull(result);
        assertEquals(bestInfo, result.getEvents());
    }

    @Test
    public void findIDFail() throws Exception {
        EventResult result = service.findSingleEvent("asdgvadfgvrwvrarrca", "bestEvent");

        assertNotNull(result);
        assertEquals(0, result.getNumEvents());
    }
}
