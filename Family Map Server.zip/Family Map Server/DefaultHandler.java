package handle;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import java.net.HttpURLConnection;
import com.google.gson.*;
import java.nio.file.*;

public class DefaultHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {

        try {

            String filePath;
            String uri = exchange.getRequestURI().toString();

            if(uri.equals("/")) {
                 filePath = "/users/guest/s/srhales/Desktop/CS 240/Family Map Server/web/index.html";
            }
            else {
                filePath = "/users/guest/s/srhales/Desktop/CS 240/Family Map Server/web" + exchange.getRequestURI();
            }

            Path path = Paths.get(filePath);

            exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK, 0);
            OutputStream response = exchange.getResponseBody();
            Files.copy(path, response);
            response.close();

        } catch (IOException e) {
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_SERVER_ERROR, 0);
            exchange.getResponseBody().close();
            e.printStackTrace();
        }
    }

}


