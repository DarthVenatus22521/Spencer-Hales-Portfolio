package test;

import model.*;
import DAO.*;
import service.*;
import result.*;
import request.*;

import java.sql.Connection;

import org.junit.*;
import static org.junit.Assert.*;

public class TestPersonID {
    Database db;
    Person bestPerson;
    Person aPerson;
    Person fury;
    PersonService service;

    @Before
    public void setUp() throws Exception {
        db = new Database();
        service = new PersonService();
        bestPerson = new Person("asdf1234", "redRum", "Johnny", "Shiney", "M", "Father", "Mother", "axeGirl");
        aPerson = new Person("comp1982", "Sam", "Kevin", "Flynn", "M", "Kevin", "Mummy", "robot");
        fury = new Person("B@dA$$MoFo", "Avengers", "Sam", "Jackson", "M", "aDad", "aMom", "Girl");
        Auth bestAuth = new Auth("bestPerson", "redRum", "7:00", "asdf1234");
        db.createTables();
            try {
            Connection conn = db.openConnection();
            PersonDAO pDao = new PersonDAO(conn);
            pDao.createPerson(aPerson);
            pDao.createPerson(fury);
            pDao.createPerson(bestPerson);
            AuthDAO aDao = new AuthDAO(conn);
            aDao.createAuth(bestAuth);
            db.closeConnection(true);
        } catch (DataAccessException e) {
            db.closeConnection(false);
        }
    }

    @After
    public void tearDown() throws Exception {
        db.clearTables();
    }

    @Test
    public void findIDPass() throws Exception {
        String bestInfo = "descendant: redRum\npersonID: asdf1234\nfirstName: Johnny\nlastName: Shiney\ngender: M\n";
        PersonResult result = service.findSinglePerson("asdf1234", "bestPerson");

        assertNotNull(result);
        assertEquals(bestInfo, result.getPersons());
    }

    @Test
    public void findIDFail() throws Exception {
        PersonResult result = service.findSinglePerson("asdgvadfgvrwvrarrca", "bestPerson");

        assertNotNull(result);
        assertEquals(0, result.getNumPeople());
    }
}
