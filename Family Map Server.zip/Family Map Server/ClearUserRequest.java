package request;

public class ClearUserRequest {

    String username;

    public ClearUserRequest(String s) {
        username = s;
    }
   
    public String toString() {
        return null;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String s) {
        username = s;
    }
}
