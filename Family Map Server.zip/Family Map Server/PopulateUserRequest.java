package request;

import model.User;

public class PopulateUserRequest {

    String username;
    User user;
    int generations = 4;
   
    public String toString() {
        return null;
    }

    public String getUsername() {
        return username;
    }

    public int getGenerations() {
        return generations;
    }

    public User getUser() {
        return user;
    }

    public void setUsername(String s) {
        username = s;
    }

    public void setGenerations(int i) {
        generations = i;
    }

    public void setUser(User u) {
        user = u;
    }
}
