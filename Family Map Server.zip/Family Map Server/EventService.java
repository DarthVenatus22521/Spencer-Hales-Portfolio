package service;

import java.sql.Connection;
import result.EventResult;
import DAO.*;
import model.*;
import java.util.*;
import java.lang.*;
import java.sql.Connection;

public class EventService {

    String username;

    public EventResult findEvents(String authToken) {
        Database db = new Database();
        try {
            db.createTables();
            EventResult result = new EventResult();
            Connection conn = db.openConnection();
            AuthDAO aDao = new AuthDAO(conn);
            Auth auth = aDao.find(authToken);
            if (auth == null) {
                throw new DataAccessException("Invalid Authorization");
            }
            String username = auth.getUser();
            EventDAO eDao = new EventDAO(conn);
            Set<Event> events = eDao.findUsername(username);
            for (Event e : events) {
                result.addEvent(e);
            }
            db.closeConnection(true);
            return result;
        }
        catch (DataAccessException d) {
            try{
                db.closeConnection(false);
            }   
            catch (DataAccessException e) {
                System.out.println(e.toString());
            }
            System.out.println(d.toString());
        }        
        return null;
    }

    public EventResult findSingleEvent(String id, String authToken) {
        if (!validate(authToken)) {
            return null;
        }

        EventResult result = new EventResult();
        result.addEvent(findEvent(id));
        return result;
    }

    private Event findEvent(String id) {
        Database db = new Database();
        try {
            db.createTables();
            Connection conn = db.openConnection();
            EventDAO pDao = new EventDAO(conn);
            Event event = pDao.find(id);
            if (event == null) {
                throw new DataAccessException("ID does not exist in User's database");
            }
            if (!event.getDescendant().equals(username)) {
                throw new DataAccessException("Invalid Authorization");
            }
            db.closeConnection(true);
            return event;
        }
        catch (DataAccessException d) {
            try{
                db.closeConnection(false);
            }   
            catch (DataAccessException e) {
                System.out.println(e.toString());
            }
            System.out.println(d.toString());
            return null;
        }        
    }

    private boolean validate(String authToken) {
        Database db = new Database();
        try {
            db.createTables();
            Connection conn = db.openConnection();
            AuthDAO aDao = new AuthDAO(conn);
            Auth auth = aDao.find(authToken);
            if (auth == null) {
                return false;
            }
            username = auth.getUser();
            db.closeConnection(true);
            return true;
        }
        catch (DataAccessException d) {
            try{
                db.closeConnection(false);
            }   
            catch (DataAccessException e) {
                System.out.println(e.toString());
            }
            return false;
        }        
    }
}
