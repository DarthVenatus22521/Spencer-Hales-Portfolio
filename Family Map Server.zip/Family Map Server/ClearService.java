package service;

import java.sql.Connection;
import result.ClearResult;
import DAO.Database;
import DAO.DataAccessException;
/**
 *Service class to handle clear requests on the server
 */
public class ClearService {

    /**
     *method to clear the database
     *returns the result of the clear
     */
    public ClearResult clear() {
        ClearResult result = new ClearResult();
        Database db = new Database();
        try {
            db.createTables();
            db.clearTables();
            result.setMessage("Clear succeeded");
        }
        catch (DataAccessException d) {
            result.setMessage(d.toString());
            d.printStackTrace();
        }
        return result;
    }

}
