package test;

import model.User;
import DAO.*;

import java.sql.Connection;

import org.junit.*;
import static org.junit.Assert.*;

//We will use this to test that our insert function is working and failing in the right ways
public class TestUserDAO {
    Database db;
    User bestUser;
    User aUser;
    User fury;

    @Before
    public void setUp() throws Exception {
        //here we can set up any classes or variables we will need for the rest of our tests
        //lets create a new database
        db = new Database();
        //and a new user with random data
        bestUser = new User("cleverUsername", "1234", "myEmail@gmail.com",
                "Johnny", "Shiney", "M", "asdf1234");
        aUser = new User("Tron", "2010", "disney@gmail.com", "Kevin", "Flynn", "M", "comp1982");
        fury = new User("Nick", "SHIELD", "marvel@gmail.com", "Sam", "Jackson", "M", "B@dA$$MoFo");
        //and make sure to initialize our tables since we don't know if our database files exist yet
        db.createTables();
    }

    @After
    public void tearDown() throws Exception {
        //here we can get rid of anything from our tests we don't want to affect the rest of our program
        //lets clear the tables so that any data we entered for testing doesn't linger in our files
        db.clearTables();
    }

    @Test
    public void insertPass() throws Exception {
        //We want to make sure insert works
        //First lets create an User that we'll set to null. We'll use this to make sure what we put
        //in the database is actually there.
        User compareTest = null;
        //Let's clear the database as well so any lingering data doesn't affect our tests
        db.clearTables();
        try {
            //Let's get our connection and make a new DAO
            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            //While insert returns a bool we can't use that to verify that our function actually worked
            //only that it ran without causing an error
            uDao.createUser(bestUser);
            //So lets use a find function to get the user that we just put in back out
            compareTest = uDao.find(bestUser.getUsername());
            db.closeConnection(true);
        } catch (DataAccessException e) {
            db.closeConnection(false);
        }
        //First lets see if our find found anything at all. If it did then we know that if nothing
        //else something was put into our database, since we cleared it in the beginning
        assertNotNull(compareTest);
        //Now lets make sure that what we put in is exactly the same as what we got out. If this
        //passes then we know that our insert did put something in, and that it didn't change the
        //data in any way
        
        assertEquals(bestUser.getUsername(), compareTest.getUsername());
        assertEquals(bestUser.getPassword(), compareTest.getPassword());
        assertEquals(bestUser.getEmail(), compareTest.getEmail());
        assertEquals(bestUser.getFirstName(), compareTest.getFirstName());
        assertEquals(bestUser.getLastName(), compareTest.getLastName());
        assertEquals(bestUser.getGender(), compareTest.getGender());
        assertEquals(bestUser.getPersonID(), compareTest.getPersonID());
    }

    @Test
    public void insertFail() throws Exception {
        db.clearTables();
        //lets do this test again but this time lets try to make it fail
        boolean didItWork = true;
        try {
            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            //if we call the function the first time it will insert it successfully
            uDao.createUser(bestUser);
            //but our sql table is set up so that "userID" must be unique. So trying to insert it
            //again will cause the function to throw an exception
            uDao.createUser(bestUser);
            db.closeConnection(didItWork);
        } catch (DataAccessException e) {
            //If we catch an exception we will end up in here, where we can change our boolean to
            //false to show that our function failed to perform correctly
            db.closeConnection(false);
            didItWork = false;
        }
        //Check to make sure that we did in fact enter our catch statement
        assertFalse(didItWork);
        //Since we know our database encountered an error, both instances of insert should have been
        //rolled back. So for added security lets make one more quick check using our find function
        //to make sure that our user is not in the database
        //Set our compareTest to an actual user
        User compareTest = bestUser;
        try {
            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            //and then get something back from our find. If the user is not in the database we
            //should have just changed our compareTest to a null object
            compareTest = uDao.find(bestUser.getUsername());
            db.closeConnection(true);
        } catch (DataAccessException e) {
            db.closeConnection(false);
        }
        //Now make sure that compareTest is indeed null

        assertNull(compareTest);

    }

    @Test
    public void findPass() throws Exception {
        User compareTest = null;

        db.clearTables();
        try {

            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            
            uDao.createUser(bestUser);
            uDao.createUser(aUser);
            uDao.createUser(fury);
            //Find a valid user
            compareTest = uDao.find(aUser.getUsername());
            db.closeConnection(true);
        } catch (DataAccessException e) {
            db.closeConnection(false);
        }

        assertEquals(aUser.getUsername(), compareTest.getUsername());
        assertEquals(aUser.getPassword(), compareTest.getPassword());
        assertEquals(aUser.getEmail(), compareTest.getEmail());
        assertEquals(aUser.getFirstName(), compareTest.getFirstName());
        assertEquals(aUser.getLastName(), compareTest.getLastName());
        assertEquals(aUser.getGender(), compareTest.getGender());
        assertEquals(aUser.getPersonID(), compareTest.getPersonID());
    }

    @Test
    public void findFail() throws Exception {
        User compareTest = fury;

        db.clearTables();
        try {

            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            
            uDao.createUser(bestUser);
            uDao.createUser(aUser);
            //Find an invalid user, which should set compare to null
            compareTest = uDao.find(fury.getUsername());
            db.closeConnection(true);
        } catch (DataAccessException e) {
            db.closeConnection(false);
        }

        assertNull(compareTest);
    }

    @Test
    public void clearPass() throws Exception {
        User compareTest = fury;

        db.clearTables();
        try {

            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            
            uDao.createUser(bestUser);
            uDao.createUser(aUser);
            uDao.createUser(fury);
            //clear the database, which should result in a null response even though the user was put in
            uDao.clear();
            compareTest = uDao.find(fury.getUsername());
            db.closeConnection(true);
        } catch (DataAccessException e) {
            db.closeConnection(false);
        }

        assertNull(compareTest);
    }

    public void clearFail() throws Exception {
        boolean didItWork = true;
        //going to clear tables with database clear command then attempt to clear the Users table from UserDAO object
        db.clearTables();
        try {

            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            
            uDao.clear();
            db.closeConnection(true);
        } catch (DataAccessException e) {
            db.closeConnection(false);
            didItWork = false;
        }

        //assertFalse(didItWork);
    }
}
