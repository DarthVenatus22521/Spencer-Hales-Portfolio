package test;

import service.*;
import result.*;
import request.RegisterRequest;
import model.*;

import org.junit.*;
import static org.junit.Assert.*;

public class TestRegister {
    RegisterService service;
    RegisterRequest request;

    @Before
    public void setUp() throws Exception {
        ClearService clearService = new ClearService();
        ClearResult clearResult = clearService.clear();
        service = new RegisterService();
        request = new RegisterRequest("username", "password", "anEmail", "firstname", "lastname", "m");
    }

    @After
    public void tearDown() throws Exception {
        ClearService clearService = new ClearService();
        ClearResult clearResult = clearService.clear();
    }

    @Test
    public void registerPass() throws Exception {
        RegisterResult result = service.register(request);

        assertNotNull(result);
        
        assertEquals(true, result.wasFail());
    }

    @Test
    public void registerFail() throws Exception {
        RegisterResult result = service.register(request);
        result = service.register(request);

        assertNotNull(result);
        
        assertEquals(false, result.wasFail());
    }
}
