package model;

/**
* Model class for Event objects
*/
public class Event {

    String eventID;
    String descendant;
    String personID;
    String latitude;
    String longitude;
    String country;
    String city;
    String eventType;
    String year;

    public Event(String event, String descend, String person, String ltitude, String lngitude, String cntry, String c, String type, String y) {
        eventID = event;
        descendant = descend;
        personID = person;
        latitude = ltitude;
        longitude = lngitude;
        country = cntry;
        city = c;
        eventType = type;
        year = y;
    }

    public String getEventID() {return eventID;}

    public String getDescendant() {return descendant;}

    public String getPersonID() {return personID;}

    public String getLatitude() {return latitude;}

    public String getLongitude() {return longitude;}

    public String getCountry() {return country;}

    public String getCity() {return city;}

    public String getEventType() {return eventType;}

    public String getYear() {return year;}

    public void getEventID(String s) {eventID = s;}

    public void getDescendant(String s) {descendant = s;}

    public void getPersonID(String s) {personID = s;}

    public void getLatitide(String s) {latitude = s;}

    public void getLongitude(String s) {longitude = s;}

    public void getCountry(String s) {country = s;}

    public void getCity(String s) {city = s;}

    public void getEventType(String s) {eventType = s;}

    public void getYear(String s) {year = s;}

        @Override 
	public boolean equals(Object o) {  
            if (o == null) {
                return false;
            }
            if (o.getClass() != this.getClass()) {
                return false;
            }
            else {
                Event obj = (Event) o;
                if (!obj.getEventID().equals(this.getEventID())) {
                    return false;
                }
                if (!obj.getDescendant().equals(this.getDescendant())) {
                    return false;
                }
                if (!obj.getPersonID().equals(this.getPersonID())) {
                    return false;
                }
                if (!obj.getLatitude().equals(this.getLatitude())) {
                    return false;
                }
                if (!obj.getLongitude().equals(this.getLongitude())) {
                    return false;
                }
                if (!obj.getCountry().equals(this.getCountry())) {
                    return false;
                }
                if (!obj.getCity().equals(this.getCity())) {
                    return false;
                }
                if (!obj.getEventType().equals(this.getEventType())) {
                    return false;
                }
                if (!obj.getYear().equals(this.getYear())) {
                    return false;
                }
            }
            return true;
        }
}
