package service;

import request.PopulateUserRequest;
import result.PopulateUserResult;
import DAO.*;
import model.*;
import java.util.*;
import java.io.*;
import java.sql.Connection;
import com.google.gson.*;
import org.json.*;
import javax.json.Json;
import javax.json.stream.JsonParser;

public class PopulateUserService {

    int generations = 0;
    int numPersons = 0;
    int numEvents = 0;

    int curYear = 2019;

    RandomString randStr;
    User baseUser;

    ArrayList<String> femaleNames;
    ArrayList<String> maleNames;
    ArrayList<String> lastNames;
    ArrayList<Location> locations;

    private Connection conn;

    public PopulateUserService(Connection c) {
        conn = c;
        randStr = new RandomString();
        femaleNames = new ArrayList<String>();
        maleNames = new ArrayList<String>();
        lastNames = new ArrayList<String>();
        locations = new ArrayList<Location>();
        baseUser = null;
    }

    public int getNumPersons() {
        return numPersons;
    }

    public int getNumEvents() {
        return numEvents;
    }

    public PopulateUserResult populate(PopulateUserRequest r) {
        PopulateUserResult result = new PopulateUserResult();
        try {
            UserDAO uDao = new UserDAO(conn);
            baseUser = r.getUser();
            if (baseUser == null) {
                throw new DataAccessException("Username does not exist");
            }
            if (r.getGenerations() < 0) {
                generations = r.getGenerations();
                throw new DataAccessException("number of generations must be a positive integer");
            }
            generations = r.getGenerations();
            PersonDAO pDao = new PersonDAO(conn);
            EventDAO eDao = new EventDAO(conn);
            getInfo();
            Person basePerson = createPersons(baseUser.getPersonID(), baseUser.getUsername(), 0, baseUser.getLastName(), baseUser.getPersonID(), baseUser.getGender());
            result.setMessage("Successfully added " + numPersons + " persons and " + numEvents + " events to the database.");
        }
        catch (DataAccessException d) {
            result.setMessage(d.toString());
            System.out.println(d.toString());
        }
        return result;
    }

    private Person createPersons(String personID, String username, int generation, String lName, String spouse_ID, String gender) throws DataAccessException {
        if (generation > generations) {
            return null;
        }

        String id = personID;
        String firstName = null;
        String lastName = null;
        String fatherID = randStr.generate();
        String motherID = randStr.generate();
        String spouseID = spouse_ID;

        if (generation == 0) {
            createEvent("Birth", username, id, "", 0);
            firstName = baseUser.getFirstName();
            lastName = baseUser.getLastName();
            Person spouse = createSpouse(username, lastName, id, invertGender(gender));
            createEvent("Marriage", username, id, spouse.getPerson(), 0);
            Person father = createPersons(fatherID, username, (generation + 1), lastName, motherID, "m");
            Person mother = createPersons(motherID, username, (generation + 1), lastName, fatherID, "f");
            father.setSpouse(mother.getPerson());
            createEvent("Marriage", username, father.getPerson(), mother.getPerson(), (generation + 1));
        }
        else {
            if (gender.equals("m")) {
                firstName = getMaleName();
                lastName = lName;
                if (generation != generations) {
                    Person father = createPersons(fatherID, username, (generation + 1), lastName, motherID, "m");
                    Person mother = createPersons(motherID, username, (generation + 1), lastName, fatherID, "f");
                    father.setSpouse(mother.getPerson());
                    createEvent("Marriage", username, father.getPerson(), mother.getPerson(), (generation + 1));
                }
                else {
                    fatherID = "";
                    motherID = "";
                }
            }
            else {
                firstName = getFemaleName();
                lastName = getLastName();
                if (generation != generations) {
                    Person father = createPersons(fatherID, username, (generation + 1), lastName, motherID, "m");
                    Person mother = createPersons(motherID, username, (generation + 1), lastName, fatherID, "f");
                    father.setSpouse(mother.getPerson());
                    createEvent("Marriage", username, father.getPerson(), mother.getPerson(), (generation + 1));
                }
                else {
                    fatherID = "";
                    motherID = "";
                }
            }
            createEvent("Birth", username, id, "", generation);
        }
        
        if (generation > 1) {
            createEvent("Death", username, id, "", generation);
        }
        Person curPerson = new Person(id, username, firstName, lastName, gender, fatherID, motherID, spouseID);
        PersonDAO pDao = new PersonDAO(conn);
        pDao.createPerson(curPerson);
        numPersons++;
        return curPerson;
    }

    private Person createSpouse(String username, String lName, String spouse_ID, String gender) throws DataAccessException {
            String id = randStr.generate();
            String firstName = baseUser.getFirstName();
            Person spouse = new Person(id, username, firstName, lName, gender, "", "", spouse_ID);
            PersonDAO pDao = new PersonDAO(conn);
            pDao.createPerson(spouse);
            numPersons++;
            createEvent("Birth", username, id, "", 0);
            return spouse;
    }

    private String invertGender(String gender) {
        if (gender.equals("m"))  {
            return "f";
        }
        else {
            return "m";
        }
    }

    private void createEvent(String eventType, String username, String personID, String spouseID, int generation) throws DataAccessException {
        EventDAO eDao = new EventDAO(conn);

        Location loc = getLocation();
        String id = randStr.generate();
        String country = loc.getCountry();
        String city = loc.getCity();
        String latitude = loc.getLatitude();
        String longitude = loc.getLongitude();
        int years;

        Random rand = new Random();
        int genYears = (25 * (generation + 1)) - rand.nextInt(7);

        if (eventType.equals("Birth")) {
            years = genYears;
        }
        else if (eventType.equals("Marriage")) {
            years = genYears - (18 + rand.nextInt(5));
            eDao.createEvent(new Event(randStr.generate(), username, spouseID, latitude, longitude, country, city, eventType, Integer.toString(curYear - years)));
            numEvents++;
        }
        else if (eventType.equals("Death")) {
            years = genYears - (45 + rand.nextInt(25));
        }
        else {
            years = genYears - (20 + rand.nextInt(12));
        }
        int year = curYear - years;
        if (year > curYear) {
            year = curYear;
        }
        eDao.createEvent(new Event(id, username, personID, latitude, longitude, country, city, eventType, Integer.toString(year)));
        numEvents++;
    }

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
    private void getInfo() {
        getFemaleInfo();
        getMaleInfo();
        getLastNameInfo();
        getLocationInfo();
    }

    private void getFemaleInfo() {
        try (FileReader fileReader = new FileReader("/users/guest/s/srhales/Desktop/CS 240/Family Map Server/json/fnames.json");
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            JSONTokener tokener = new JSONTokener(bufferedReader);
            JSONObject rootObj = new JSONObject(tokener);
            JSONArray infoArray = rootObj.getJSONArray("data");
            for (int i = 0; i < infoArray.length(); i++) {
                String name = infoArray.getString(i);
                femaleNames.add(name);
            }
        }
        catch(Exception e) {
            System.out.println("Error getting Female name" + e.toString());
        }
    }

    private void getMaleInfo() {
        try (FileReader fileReader = new FileReader("/users/guest/s/srhales/Desktop/CS 240/Family Map Server/json/mnames.json");
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            JSONTokener tokener = new JSONTokener(bufferedReader);
            JSONObject rootObj = new JSONObject(tokener);
            JSONArray infoArray = rootObj.getJSONArray("data");
            for (int i = 0; i < infoArray.length(); i++) {
                String name = infoArray.getString(i);
                maleNames.add(name);
            }
        }
        catch(Exception e) {
            System.out.println("Error getting Male name" + e.toString());
        }
    }

    private void getLastNameInfo() {
        try (FileReader fileReader = new FileReader("/users/guest/s/srhales/Desktop/CS 240/Family Map Server/json/snames.json");
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            JSONTokener tokener = new JSONTokener(bufferedReader);
            JSONObject rootObj = new JSONObject(tokener);
            JSONArray infoArray = rootObj.getJSONArray("data");
            for (int i = 0; i < infoArray.length(); i++) {
                String name = infoArray.getString(i);
                lastNames.add(name);
            }
        }
        catch(Exception e) {
            System.out.println("Error getting Last Name" + e.toString());
        }
    }

    private void getLocationInfo() {
        try (FileReader fileReader = new FileReader("/users/guest/s/srhales/Desktop/CS 240/Family Map Server/json/locations.json");
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            JSONTokener tokener = new JSONTokener(bufferedReader);
            JSONObject rootObj = new JSONObject(tokener);
            JSONArray infoArray = rootObj.getJSONArray("data");

            for (int i = 0; i < infoArray.length(); i++) {
                JSONObject elemObj = infoArray.getJSONObject(i);
                String country = elemObj.getString("country");
                String city = elemObj.getString("city");
                String latitude = elemObj.getDouble("latitude")+"";
                String longitude = elemObj.getDouble("longitude")+"";
                locations.add(new Location(country, city, latitude, longitude));
            }
        }
        catch(Exception e) {
            System.out.println("Error getting Locations" + e.toString());
        }
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------------
    private String getFemaleName() {
        Random rand = new Random();
        int i = rand.nextInt(femaleNames.size());
        return femaleNames.get(i);
    }

    private String getMaleName() {
        Random rand = new Random();
        int i = rand.nextInt(maleNames.size());
        return maleNames.get(i);
    }

    private String getLastName() {
        Random rand = new Random();
        int i = rand.nextInt(lastNames.size());
        return lastNames.get(i);
    }

    private Location getLocation() {
        Random rand = new Random();
        int i = rand.nextInt(locations.size());
        return locations.get(i);
    }
}
