package model;

public class Location {
    String country;
    String city;
    String latitude;
    String longitude;

    public Location(String count, String cty, String lat, String lng) {
        country = count;
        city = cty;
        latitude = lat;
        longitude = lng;
    }

    public void setCountry(String s) {
        country = s;
    }

    public void setCity(String s) {
        city = s;
    }

    public void setLatitude(String s) {
        latitude = s;
    }

    public void setLongitude(String s) {
        longitude = s;
    }

    public String getCountry() {
        return country;
    }

    public String getCity() {
        return city;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }
}
