package handle;

import service.FillService;
import request.FillRequest;
import result.FillResult;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import java.net.HttpURLConnection;
import com.google.gson.*;
import java.net.*;

public class FillHandler implements HttpHandler{
        
        @Override
    public void handle(HttpExchange exchange) throws IOException {
        try {
            boolean success = false;
            Gson gson = new Gson();
            if (exchange.getRequestMethod().toLowerCase().equals("post")) {
                FillRequest fillRequest = new FillRequest();
                URI uri = exchange.getRequestURI();
                String[] commands = uri.getPath().split("/");
                fillRequest.setUsername(commands[2]);
                if (commands.length == 3) {
                    fillRequest.setGenerations(4);
                }
                else {
                    fillRequest.setGenerations(Integer.parseInt(commands[3]));
                }

                FillService fillService = new FillService();
                FillResult fillResult = fillService.fill(fillRequest);
                String response = gson.toJson(fillResult);

                exchange.sendResponseHeaders(HttpURLConnection.HTTP_OK,0);
                OutputStream respBody = exchange.getResponseBody();
                writeString(response, respBody);
                respBody.close();
                exchange.getResponseBody().close();
                success = true;
            }
            if (!success) {
                exchange.sendResponseHeaders(HttpURLConnection.HTTP_BAD_REQUEST, 0);
                exchange.getResponseBody().close();
            }
        }
        catch(IOException e) {
            exchange.sendResponseHeaders(HttpURLConnection.HTTP_SERVER_ERROR, 0);
            exchange.getResponseBody().close();
            System.out.println(e.toString());
            e.printStackTrace();
        }
    }

    private void writeString(String str, OutputStream os) throws IOException {
        OutputStreamWriter osw = new OutputStreamWriter(os);
        osw.write(str);
        osw.flush();
    }
}
