package DAO;

import java.util.*;
import java.lang.*;
import java.io.*;
import java.sql.*;

import model.Event;

public class EventDAO {

   private Connection conn;

   public EventDAO(Connection conn)
   {
       this.conn = conn;
   }

   public void createEvent(Event event) throws DataAccessException {
        if (!insert(event)) {
            throw new DataAccessException("Error encountered while inserting into the database");
        }
   }

    public void deleteUser(String username) throws DataAccessException {
        String sql = "DELETE FROM Events WHERE Descendant = ?;";
        try(PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            throw new DataAccessException("Error occurred when clearing user " + username + "'s data from Events table");
        }
    }

   public void clear() throws DataAccessException {
        String sql = "DELETE FROM Events";        
        try(PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            throw new DataAccessException("Error occurred when clearing data from table");
        }
   }
//----------------------------------------------------------------------------------------------------

    public boolean insert(Event event) throws DataAccessException {
        boolean commit = true;
        //We can structure our string to be similar to a sql command, but if we insert question
        //marks we can change them later with help from the statement
        String sql = "INSERT INTO Events (EventID, Descendant, PersonID, Latitude, Longitude, " +
                "Country, City, EventType, Year) VALUES(?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            //Using the statements built-in set(type) functions we can pick the question mark we want
            //to fill in and give it a proper value. The first argument corresponds to the first
            //question mark found in our sql String
            stmt.setString(1, event.getEventID());
            stmt.setString(2, event.getDescendant());
            stmt.setString(3, event.getPersonID());
            stmt.setString(4, event.getLatitude());
            stmt.setString(5, event.getLongitude());
            stmt.setString(6, event.getCountry());
            stmt.setString(7, event.getCity());
            stmt.setString(8, event.getEventType());
            stmt.setString(9, event.getYear());

            stmt.executeUpdate();
        } catch (SQLException e) {
            commit = false;
        }

        return commit;
    }

    public Event find(String eventID) throws DataAccessException {
        Event event = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM Events WHERE EventID = ?;";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, eventID);
            rs = stmt.executeQuery();
            if (rs.next() == true) {
                event = new Event(rs.getString("EventID"), rs.getString("Descendant"),
                        rs.getString("PersonID"), rs.getString("Latitude"), rs.getString("Longitude"),
                        rs.getString("Country"), rs.getString("City"), rs.getString("EventType"), rs.getString("Year"));
                return event;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DataAccessException("Error encountered while finding event");
        } finally {
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }
        return null;
    }

    public Set<Event> findUsername(String username) throws DataAccessException {
        Set<Event> events = new HashSet<Event>();
        Event event = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM Events WHERE Descendant = ?;";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            rs = stmt.executeQuery();
            while (rs.next() == true) {
                event = new Event(rs.getString("EventID"), rs.getString("Descendant"),
                        rs.getString("PersonID"), rs.getString("Latitude"), rs.getString("Longitude"),
                        rs.getString("Country"), rs.getString("City"), rs.getString("EventType"), rs.getString("Year"));
                events.add(event);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DataAccessException("Error encountered while finding all Events based on Username");
        } finally {
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }
        return events;
    }
}
