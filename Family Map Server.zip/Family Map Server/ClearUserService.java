package service;

import request.ClearUserRequest;
import result.ClearUserResult;
import DAO.*;
import model.*;
import java.sql.Connection;


public class ClearUserService {

    private Connection conn;

    public ClearUserService(Connection c) {
        conn = c;
    }

    ClearUserResult clearInfo(ClearUserRequest r) {
        ClearUserResult result = new ClearUserResult();
        try {
            PersonDAO pDao = new PersonDAO(conn);
            UserDAO uDao = new UserDAO(conn);
            EventDAO eDao = new EventDAO(conn);
            User myUser = uDao.find(r.getUsername());
            if (myUser == null) {
                throw new DataAccessException("Username does not exist in database");
            }
            Person myPerson = pDao.find(myUser.getPersonID());
            pDao.deleteUser(myPerson.getDescendant());
            eDao.deleteUser(myPerson.getDescendant());
            result.setMessage("Cleared data for person " + myUser.getPersonID());
        }
        catch (DataAccessException d) {
            result.setMessage(d.toString());
        }
        return result;
    }
}
