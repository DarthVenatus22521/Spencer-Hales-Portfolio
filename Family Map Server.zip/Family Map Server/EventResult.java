package result;

import java.util.*;
import java.lang.*;
import model.Event;

public class EventResult {
    Set<Event> events;

    public EventResult() {
        events = new HashSet<Event>();
    }

    public void addEvent(Event e) {
        if (e != null) {
            events.add(e);
        }
    }

    public String getEvents() {
        StringBuilder sb = new StringBuilder();
        for (Event e : events) {
            sb.append(getEventInfo(e) + "\n");
        }
        return sb.toString();
    }

    private String getEventInfo(Event e) {
        String info = "eventID: " + e.getEventID() + "\ndescendant: " + e.getDescendant() + "\npersonID: " + e.getPersonID() +
                      "\nlatitude: " + e.getLatitude() + "\nlongitude: " + e.getLongitude() + "\ncountry: " + e.getCountry() + 
                      "\ncity: " + e.getCity() + "\neventType: " + e.getEventType() + "\nyear: " + e.getYear() + "\n";
        return info;
    }

    public Set<Event> getEventSet() {
        return events;
    }

    public int getNumEvents() {
        return events.size();
    }
}
