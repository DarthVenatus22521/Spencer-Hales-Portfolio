package request;

import java.util.*;
import model.*;
/**
 *Class to contain information needed to start the login service
 */
public class LoadRequest {

    private User[] users;
    private Person[] persons;
    private Event[] events;
    
    Set<User> myUsers;
    Set<Person> myPersons;
    Set<Event> myEvents;

    public LoadRequest() {
        myUsers = new HashSet<User>();
        myPersons = new HashSet<Person>();
        myEvents = new HashSet<Event>();
    }

    public Set<User> getUsers() {
        myUsers.clear();
        for (User u : users) {
            myUsers.add(u);
        }
        return myUsers;
    }

    public Set<Person> getPersons() {
        myPersons.clear();
        for (Person p: persons) {
            myPersons.add(p);
        }
        return myPersons;
    }

    public Set<Event> getEvents() {
        myEvents.clear();
        for (Event e: events) {
            myEvents.add(e);
        }
        return myEvents;
    }
    
    public void setData(User[] userArray, Person[] personArray, Event[] eventArray) {
        users = userArray;
        persons = personArray;
        events = eventArray;
    }
}
