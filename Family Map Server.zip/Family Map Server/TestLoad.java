package test;

import service.*;
import result.*;
import request.LoadRequest;
import model.*;

import org.junit.*;
import static org.junit.Assert.*;

public class TestLoad {
    LoadService service;
    LoadRequest request;
    LoadResult testResult;

    @Before
    public void setUp() throws Exception {
        service = new LoadService();
        request = new LoadRequest();
        testResult = new LoadResult();
        testResult.setMessage("Successfully added 1 users, 1 persons, and 1 events to the database.");
        User bestUser = new User("cleverUsername", "1234", "myEmail@gmail.com", "Johnny", "Shiney", "M", "asdf1234");
        User[] users = {bestUser};
        Person bestPerson = new Person("asdf1234", "redRum", "Johnny", "Shiney", "M", "Father", "Mother", "axeGirl");
        Person[] persons = {bestPerson};
        Event bestEvent = new Event("1243", "Son", "aPerson", "12", "21", "United Kingdom", "London", "Mystery", "2019");
        Event[] events = {bestEvent};
        request.setData(users, persons, events);
    }

    @After
    public void tearDown() throws Exception {
        ClearService clearService = new ClearService();
        ClearResult clearResult = clearService.clear();
    }

    @Test
    public void loadPass() throws Exception {
        LoadResult result = service.load(request);

        assertNotNull(result);
        
        assertEquals(testResult.resultMsg(), result.resultMsg());
    }
}
