package service;

import java.sql.Connection;
import result.LoadResult;
import request.LoadRequest;
import result.ClearResult;
import model.User;
import model.Person;
import model.Event;
import DAO.*;
import java.util.*;

public class LoadService {


    public LoadResult load(LoadRequest r) {
        Database db = new Database();
        LoadResult result = new LoadResult();
        try {
            ClearService consuela = new ClearService();
            ClearResult clearResult = consuela.clear();

            db.createTables();
            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            PersonDAO pDao = new PersonDAO(conn);
            EventDAO eDao = new EventDAO(conn);

            loadUserInfo(r.getUsers(), uDao);
            loadPersonInfo(r.getPersons(), pDao);
            loadEventInfo(r.getEvents(), eDao);

            result.setMessage("Successfully added " + r.getUsers().size() +" users, " + r.getPersons().size() +" persons, and " + r.getEvents().size() +" events to the database.");
            db.closeConnection(true);
        }
        catch (DataAccessException d) {
            try{
                db.closeConnection(false);
            }   
            catch (DataAccessException e) {
                System.out.println(e.toString());
            }
            result.setMessage(d.toString());
        }
        return result;
    }

    public void loadUserInfo(Set<User> users, UserDAO uDao) throws DataAccessException {        
        for (User u : users) {
            uDao.createUser(u);
        }
    }

    public void loadPersonInfo(Set<Person> persons, PersonDAO pDao) throws DataAccessException {
        for (Person p : persons) {
            pDao.createPerson(p);
        }
    }

    public void loadEventInfo(Set<Event> events, EventDAO eDao) throws DataAccessException {
        for (Event e : events) {
            eDao.createEvent(e);
        }
    }
}
