package service;

import java.sql.Connection;
import request.FillRequest;
import result.FillResult;
import request.ClearUserRequest;
import result.ClearUserResult;
import request.PopulateUserRequest;
import result.PopulateUserResult;
import DAO.*;
import model.*;
/**
 *Service class to handle fill requests
 */
public class FillService {

    /**
     *method to handle filling the database
     *pushes in a fillRequest object with the info needed to fill
     *returns the result of the fill
     */
    public FillResult fill(FillRequest r) {
        Database db = new Database();
        FillResult result = new FillResult();
        try {
            db.createTables();
            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            User baseUser = uDao.find(r.getUsername());
            if (baseUser == null) {
                throw new DataAccessException("Username does not exist");
            }
            if (r.getGenerations() < 0) {
                throw new DataAccessException("Number of generations must be a positive integer");
            }

            ClearUserRequest clearUser = new ClearUserRequest(baseUser.getUsername());
            ClearUserService userService = new ClearUserService(conn);
            ClearUserResult clrUserRslt = userService.clearInfo(clearUser);

            PopulateUserRequest popRequest = new PopulateUserRequest();
            popRequest.setUser(baseUser);
            popRequest.setGenerations(r.getGenerations());
            PopulateUserService createFamily = new PopulateUserService(conn);
            PopulateUserResult famResult = createFamily.populate(popRequest);
            
            result.setMessage(famResult.resultMsg());
            db.closeConnection(true);
            return result;
        }
        catch (DataAccessException d) {
            try{
                db.closeConnection(false);
            }   
            catch (DataAccessException e) {
                System.out.println(e.toString());
            }
            result.setMessage(d.toString());
        }
        return result;
    }
}
