package test;

import service.ClearService;
import result.ClearResult;

import org.junit.*;
import static org.junit.Assert.*;

public class TestClear {
    ClearService service;
    ClearResult testResult;

    @Before
    public void setUp() throws Exception {
        service = new ClearService();
        testResult = new ClearResult();
        testResult.setMessage("Clear succeeded");
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void clearPass() throws Exception {
        ClearResult result = service.clear();

        assertNotNull(result);
        
        assertEquals(testResult.resultMsg(), result.resultMsg());
    }

    @Test
    public void twoClearPass() throws Exception {
        ClearResult result = service.clear();
        result = service.clear();

        assertNotNull(result);
        
        assertEquals(testResult.resultMsg(), result.resultMsg());
    }
}
