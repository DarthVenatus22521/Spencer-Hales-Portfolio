package service;

import java.sql.Connection;
import result.PersonResult;
import DAO.*;
import model.*;
import java.util.*;
import java.lang.*;
import java.sql.Connection;

public class PersonService {

    String username;

    public PersonResult findPeople(String authToken) {
        Database db = new Database();
        try {
            db.createTables();
            PersonResult result = new PersonResult();
            Connection conn = db.openConnection();
            AuthDAO aDao = new AuthDAO(conn);
            Auth auth = aDao.find(authToken);
            if (auth == null) {
                throw new DataAccessException("auth token was invalid");
            }
            String username = auth.getUser();
            PersonDAO pDao = new PersonDAO(conn);
            Set<Person> people = pDao.findUsername(username);
            for (Person p : people) {
                result.addPerson(p);
            }
            db.closeConnection(true);
            return result;
        }
        catch (DataAccessException d) {
            try{
                db.closeConnection(false);
            }   
            catch (DataAccessException e) {
                System.out.println(e.toString());
            }
        }        
        return null;
    }

    public PersonResult findSinglePerson(String id, String authToken) {
        if (!validate(authToken)) {
            return null;
        }
        PersonResult result = new PersonResult();
        result.addPerson(findPerson(id));
        return result;
    }

    private Person findPerson(String id) {
        Database db = new Database();
        try {
            db.createTables();
            Connection conn = db.openConnection();
            PersonDAO pDao = new PersonDAO(conn);
            Person person = pDao.find(id);
            if (person == null) {
                throw new DataAccessException("ID does not exist in User's database");
            }
            if (!person.getDescendant().equals(username)) {
                throw new DataAccessException("Invalid Authorization");
            }
            db.closeConnection(true);
            return person;
        }
        catch (DataAccessException d) {
            try{
                db.closeConnection(false);
            }   
            catch (DataAccessException e) {
                System.out.println(e.toString());
            }
            System.out.println(d.toString());
            return null;
        }        
    }

    private boolean validate(String authToken) {
        Database db = new Database();
        try {
            db.createTables();
            Connection conn = db.openConnection();
            AuthDAO aDao = new AuthDAO(conn);
            Auth auth = aDao.find(authToken);
            if (auth == null) {
                return false;
            }
            username = auth.getUser();
            db.closeConnection(true);
            return true;
        }
        catch (DataAccessException d) {
            try{
                db.closeConnection(false);
            }   
            catch (DataAccessException e) {
                System.out.println(e.toString());
            }
            return false;
        }        
    }
}
