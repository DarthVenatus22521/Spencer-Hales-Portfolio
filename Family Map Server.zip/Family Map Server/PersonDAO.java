package DAO;

import java.util.*;
import java.lang.*;
import java.io.*;
import java.sql.*;

import model.Person;

public class PersonDAO {

   private Connection conn;

   public PersonDAO(Connection conn)
   {
       this.conn = conn;
   }

   public void createPerson(Person person) throws DataAccessException {
        if (!insert(person)) {
            throw new DataAccessException("Error encountered while inserting Person into the database");
        }
   }

   public void delete(String personID) throws DataAccessException {
        String sql = "DELETE FROM Persons WHERE PersonID = ?;";
        try(PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, personID);
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            throw new DataAccessException("Error occurred when clearing " + personID + " from table");
        }
   }

    public void deleteUser(String username) throws DataAccessException {
        String sql = "DELETE FROM Persons WHERE Descendant = ?;";
        try(PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            throw new DataAccessException("Error occurred when clearing user " + username + "'s data from table");
        }
    }

   public void clear() throws DataAccessException {
        String sql = "DELETE FROM Persons";
        try(PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            throw new DataAccessException("Error occurred when clearing Persons data from table");
        }
   }

    public boolean insert(Person person) throws DataAccessException {
        boolean commit = true;
        Person p = checkNull(person);
        //We can structure our string to be similar to a sql command, but if we insert question
        //marks we can change them later with help from the statement
        String sql = "INSERT INTO Persons (PersonID, Descendant, FirstName, LastName, " +
                "Gender, Father, Mother, Spouse) VALUES(?,?,?,?,?,?,?,?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            //Using the statements built-in set(type) functions we can pick the question mark we want
            //to fill in and give it a proper value. The first argument corresponds to the first
            //question mark found in our sql String
            stmt.setString(1, p.getPerson());
            stmt.setString(2, p.getDescendant());
            stmt.setString(3, p.getFirstName());
            stmt.setString(4, p.getLastName());
            stmt.setString(5, p.getGender());
            stmt.setString(6, p.getFather());
            stmt.setString(7, p.getMother());
            stmt.setString(8, p.getSpouse());

            stmt.executeUpdate();
        } catch (SQLException e) {
            //System.out.println(e.toString());
            commit = false;
        }

        return commit;
    }

    public Person find(String personID) throws DataAccessException {
        Person person = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM Persons WHERE PersonID = ?;";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, personID);
            rs = stmt.executeQuery();
            if (rs.next() == true) {
                person = new Person(rs.getString("PersonID"), rs.getString("Descendant"),
                        rs.getString("FirstName"), rs.getString("LastName"), rs.getString("Gender"),
                        rs.getString("Father"), rs.getString("Mother"), rs.getString("Spouse"));
                return person;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DataAccessException("Error encountered while finding Person");
        } finally {
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }
        return null;
    }

    public Set<Person> findUsername(String username) throws DataAccessException {
        Set<Person> people = new HashSet<Person>();
        Person person = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM Persons WHERE Descendant = ?;";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            rs = stmt.executeQuery();
            while (rs.next() == true) {
                person = new Person(rs.getString("PersonID"), rs.getString("Descendant"),
                        rs.getString("FirstName"), rs.getString("LastName"), rs.getString("Gender"),
                        rs.getString("Father"), rs.getString("Mother"), rs.getString("Spouse"));
                people.add(person);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DataAccessException("Error encountered while finding all People based on Username");
        } finally {
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }
        return people;
    }

    private Person checkNull(Person p) {
        Person person = p;
        if (person.getFather() == null) {
            person.setFather("null");
        }
        if (person.getMother() == null) {
            person.setMother("null");
        }
        if (person.getSpouse() == null) {
            person.setSpouse("null");
        }
        return person;
    }
}
