package DAO;

import java.util.*;
import java.lang.*;
import java.io.*;
import java.sql.*;

import model.Auth;

public class AuthDAO {

   private Connection conn;

   public AuthDAO(Connection conn)
   {
       this.conn = conn;
   }

   public void createAuth(Auth auth) throws DataAccessException {
        if (!insert(auth)) {
            throw new DataAccessException("Error encountered while inserting into the database");
        }
   }

   public Auth getAuth(String id) throws DataAccessException {
        return find(id);
   }

   public void clear() throws DataAccessException {
        String sql = "DELETE FROM Auth";        
        try(PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.executeUpdate();
        }
        catch (SQLException e) {
            throw new DataAccessException("Error occurred when clearing data from table");
        }
   }
//----------------------------------------------------------------------------------------------------

    public boolean insert(Auth auth) throws DataAccessException {
        boolean commit = true;
        //We can structure our string to be similar to a sql command, but if we insert question
        //marks we can change them later with help from the statement
        String sql = "INSERT INTO Auth (AuthToken, Username, Timeout, PersonID) VALUES(?,?,?,?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            //Using the statements built-in set(type) functions we can pick the question mark we want
            //to fill in and give it a proper value. The first argument corresponds to the first
            //question mark found in our sql String
            stmt.setString(1, auth.getAuthToken());
            stmt.setString(2, auth.getUser());
            stmt.setString(3, auth.getTimeout());
            stmt.setString(4, auth.getPersonID());

            stmt.executeUpdate();
        } catch (SQLException e) {
            //System.out.println(e.toString());
            commit = false;
        }

        return commit;
    }

    public Auth find(String authID) throws DataAccessException {
        Auth auth = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM Auth WHERE AuthToken = ?;";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, authID);
            rs = stmt.executeQuery();
            if (rs.next() == true) {
                auth = new Auth(rs.getString("AuthToken"), rs.getString("Username"),
                        rs.getString("Timeout"), rs.getString("PersonID"));
                return auth;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DataAccessException("Error encountered while finding event");
        } finally {
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }
        return null;
    }
}
