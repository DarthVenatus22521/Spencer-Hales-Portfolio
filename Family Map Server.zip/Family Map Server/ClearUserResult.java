package result;


public class ClearUserResult {
    
    String message;


    public String resultMsg() {
        return message;
    }

    public void setMessage(String msg) {
        message = msg;
    }

    public String getMessage() {
        return message;
    }
}
