package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by westenm on 2/4/19.
 */

public class Database {
    private Connection conn;

    static {
        try {
            //This is how we set up the driver for our database
            final String driver = "org.sqlite.JDBC";
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    //Whenever we want to make a change to our database we will have to open a connection and use
    //Statements created by that connection to initiate transactions
    public Connection openConnection() throws DataAccessException {
        try {
            //The Structure for this Connection is driver:language:path
            //The pathing assumes you start in the root of your project unless given a non-relative path
            //final String CONNECTION_URL = "jdbc:sqlite:familymap.sqlite";
            final String CONNECTION_URL = "jdbc:sqlite:database.db";

            // Open a database connection to the file given in the path
            conn = DriverManager.getConnection(CONNECTION_URL);

            // Start a transaction
            conn.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DataAccessException("Unable to open connection to database");
        }

        return conn;
    }

    //When we are done manipulating the database it is important to close the connection. This will
    //End the transaction and allow us to either commit our changes to the database or rollback any
    //changes that were made before we encountered a potential error.

    //IMPORTANT: IF YOU FAIL TO CLOSE A CONNECTION AND TRY TO REOPEN THE DATABASE THIS WILL CAUSE THE
    //DATABASE TO LOCK. YOUR CODE MUST ALWAYS INCLUDE A CLOSURE OF THE DATABASE NO MATTER WHAT ERRORS
    //OR PROBLEMS YOU ENCOUNTER
    public void closeConnection(boolean commit) throws DataAccessException {
        try {
            if (commit) {
                //This will commit the changes to the database
                conn.commit();
            } else {
                //If we find out something went wrong, pass a false into closeConnection and this
                //will rollback any changes we made during this connection
                conn.rollback();
            }

            conn.close();
            conn = null;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new DataAccessException("Unable to close database connection");
        }
    }

    public void createTables() throws DataAccessException {
	    openConnection();
	    try (Statement stmt = conn.createStatement()){
		    String sqlUsers = "CREATE TABLE IF NOT EXISTS Users " +
                    "(" +
                    "Username text not null unique, " +
                    "Password text not null, " +
                    "Email text not null, " +
                    "FirstName text not null, " +
                    "LastName text not null, " +
                    "Gender text not null, " +
                    "PersonID text not null, " +
                    "primary key (Username), " +
                    "foreign key (FirstName) references Persons(FirstName), " +
                    "foreign key (LastName) references Persons(LastName)" +
                    "foreign key (PersonID) references Persons(PersonID)" +
                    ")";
            stmt.executeUpdate(sqlUsers);

            String sqlPersons = "CREATE TABLE IF NOT EXISTS Persons " +
                    "(" +
                    "PersonID text not null unique," +
	                "Descendant text not null," +
	                "FirstName text not null," +
	                "LastName text not null," +
	                "Gender text not null," +
	                "Father text not null," +
	                "Mother text not null," +
	                "Spouse text not null," +
                    "primary key (PersonID)," +
                    "foreign key (FirstName) references Users(FirstName), " +
                    "foreign key (LastName) references Users(LastName)" +
                    "foreign key (PersonID) references Users(PersonID)" +
                    ")";
            stmt.executeUpdate(sqlPersons);

            String sqlEvents = "CREATE TABLE IF NOT EXISTS Events " +
                    "(" +
                    "EventID text not null unique," +
	                "Descendant text not null," +
	                "PersonID text not null," +
	                "Latitude text not null," +
	                "Longitude text not null," +
	                "Country text not null," +
	                "City text not null," +
	                "EventType text not null," +
	                "Year text not null," +
                    "primary key (EventID)," +
                    "foreign key (Descendant) references Users(Username)," +
                    "foreign key (PersonID) references Persons(PersonID)" + 
                    ")";
            stmt.executeUpdate(sqlEvents);

            String sqlAuth = "CREATE TABLE IF NOT EXISTS Auth " +
                    "(" + 
                    "AuthToken text not null unique," + 
                    "Username text not null," + 
                    "Timeout text not null," + 
                    "PersonID text not null," + 
                    "primary key(AuthToken)," + 
                    "foreign key (Username) references Users(Username)," + 
                    "foreign key (PersonID) references Person(PersonID)" + 
                    ")";
            stmt.executeUpdate(sqlAuth);

            closeConnection(true);
	    }
        catch (DataAccessException e) {
            //if our table creation caused an error, we can just not commit the changes that did happen
            closeConnection(false);
            throw e;
        } catch (SQLException e) {
            //if our table creation caused an error, we can just not commit the changes that did happen
            closeConnection(false);
            System.out.println(e.toString());
            throw new DataAccessException("SQL Error encountered while creating tables");
        }
    }

    public void clearTables() throws DataAccessException
    {
        openConnection();

        try (Statement stmt = conn.createStatement()){
            String sqlUsers = "DELETE FROM Users";
            stmt.executeUpdate(sqlUsers);
            String sqlPersons = "DELETE FROM Persons";
            stmt.executeUpdate(sqlPersons);
            String sqlEvents = "DELETE FROM Events";
            stmt.executeUpdate(sqlEvents);
            String sqlAuth = "DELETE FROM Auth";
            stmt.executeUpdate(sqlAuth);
            closeConnection(true);
        } catch (DataAccessException e) {
            closeConnection(false);
            throw e;
        } catch (SQLException e) {
            closeConnection(false);
            throw new DataAccessException("SQL Error encountered while clearing tables");
        }
    }
    /*public void createUsers() throws DataAccessException {
	    openConnection();
	    try (Statement stmt = conn.createStatement()){
		    String sql = "CREATE TABLE IF NOT EXISTS Users " +
                    "(" +
                    "Username text not null unique, " +
                    "Password text not null, " +
                    "Email text not null, " +
                    "FirstName text not null, " +
                    "LastName text not null, " +
                    "Gender text not null, " +
                    "PersonID text not null, " +
                    "primary key (Username), " +
                    "foreign key (FirstName) references Persons(FirstName), " +
                    "foreign key (LastName) references Persons(LastName)" +
                    "foreign key (PersonID) references Persons(PersonID)" +
                    ")";
            stmt.executeUpdate(sql);
            closeConnection(true);
	    }
        catch (DataAccessException e) {
            //if our table creation caused an error, we can just not commit the changes that did happen
            closeConnection(false);
            throw e;
        } catch (SQLException e) {
            //if our table creation caused an error, we can just not commit the changes that did happen
            closeConnection(false);
            System.out.println(e.toString());
            throw new DataAccessException("SQL Error encountered while creating User table");
        }
    }

    public void createPersons() throws DataAccessException {
	    openConnection();
	    try (Statement stmt = conn.createStatement()) {
		    String sql = "CREATE TABLE IF NOT EXISTS Persons " +
                    "(" +
	                "PersonID text not null unique," +
	                "Descendant text not null," +
	                "FirstName text not null," +
	                "LastName text not null," +
	                "Gender text not null," +
	                "Father text not null," +
	                "Mother text not null," +
	                "Spouse text not null," +
                    "primary key (PersonID)," +
                    "foreign key (FirstName) references Users(FirstName), " +
                    "foreign key (LastName) references Users(LastName)" +
                    "foreign key (PersonID) references Users(PersonID)" +
                    ")";
            stmt.executeUpdate(sql);
            closeConnection(true);
	    }
        catch (DataAccessException e) {
            //if our table creation caused an error, we can just not commit the changes that did happen
            closeConnection(false);
            throw e;
        } catch (SQLException e) {
            //if our table creation caused an error, we can just not commit the changes that did happen
            closeConnection(false);
            System.out.println(e.toString());
            throw new DataAccessException("SQL Error encountered while creating Person table");
        }
    }*/

}
