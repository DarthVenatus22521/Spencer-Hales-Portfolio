package result;

/**
 *Object to be returned from Register service with the result of the action
 */
public class RegisterResult {

    String authToken;
    String username;
    String personID;
    String errorMessage;
    boolean success = true;
        
    /**
     *The toString method of this class
     */
    public String resultMsg() {
        if (!wasFail()) {
            return errorMessage;
        }
        return "authToken: " + getAuthToken() + "\nuserName: " + getUsername() + "\npersonID: " + getPersonID() + "\n";
    }

    public String getAuthToken() {
        return authToken;
    }

    public String getUsername() {
        return username;
    }

    public String getPersonID() {
        return personID;
    }

    public void setAuthToken(String s) {
        authToken = s;
    }

    public void setUsername(String s) {
        username = s;
    }

    public void setPersonID(String s) {
        personID = s;
    }

    public void isFail(String message) {
        success = false;
        errorMessage = message;
    }

    public boolean wasFail() {
        return success;
    }
}
