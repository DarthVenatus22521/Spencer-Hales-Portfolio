package service;

import java.sql.Connection;
import request.RegisterRequest;
import result.RegisterResult;
import request.PopulateUserRequest;
import result.PopulateUserResult;
import DAO.*;
import model.*;
/**
 *Service to handle registration of new users
 */
public class RegisterService {
    /**
     *method to register a new user
     *passes in a RegisterRequest object containing the neccessary information to register
     *returns result of the registration
     */
    public RegisterResult register(RegisterRequest r) {
        RandomString randString = new RandomString();
        String id = randString.generate();
        User user = new User(r.getUsername(), r.getPassword(), r.getEmail(), r.getFirstName(), r.getLastName(), r.getGender(), id);
        Database db = new Database();
        try {
            db.createTables();
            Connection conn = db.openConnection();
            UserDAO uDao = new UserDAO(conn);
            uDao.createUser(user);

            PopulateUserRequest popRequest = new PopulateUserRequest();
            popRequest.setUser(user);
            popRequest.setGenerations(4);
            PopulateUserService popService = new PopulateUserService(conn);
            PopulateUserResult popResult = popService.populate(popRequest);

            RegisterResult result = new RegisterResult();
            RandomString randStr = new RandomString();
            String token = randStr.generate();
            AuthDAO aDAO = new AuthDAO(conn);
            Auth auth = new Auth(token, user.getUsername(), "aTime", user.getPersonID());
            aDAO.insert(auth);
            result.setAuthToken(token);
            result.setUsername(user.getUsername());
            result.setPersonID(user.getPersonID());
            db.closeConnection(true);
            return result;
        }
        catch (DataAccessException d) {
            try{
                db.closeConnection(false);
            }   
            catch (DataAccessException e) {
                System.out.println(e.toString());
            }
            //d.printStackTrace();
            RegisterResult failResult = new RegisterResult();
            failResult.isFail(d.toString());
            return failResult;
        }
    }
}
