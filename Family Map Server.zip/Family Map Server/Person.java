package model;

/**
* Model class for Person objects
*/
public class Person {

    private String personID;
    private String descendant;
    private String firstName;
    private String lastName;
    private String gender;
    private String father;
    private String mother;
    private String spouse;

    public Person() {};

    public Person(String id, String des, String fName, String lName, String g, String f, String m, String s) {
        personID = id;
        descendant = des;
        firstName = fName;
        lastName = lName;
        gender = g;
        father = f;
        mother = m;
        spouse = s;
        if (f == null) {
            father = "null";
        }
        if (m == null) {
            mother = "null";
        }
        if (s == null) {
            spouse = "null";
        }
    }

    public String getPerson() {return personID;}

    public String getDescendant() {return descendant;}

    public String getFirstName() {return firstName;}

    public String getLastName() {return lastName;}

    public String getGender() {return gender;}

    public String getFather() {return father;}

    public String getMother() {return mother;}

    public String getSpouse() {return spouse;}

    public void setPerson(String s) {personID = s;}

    public void setDescendant(String s) {descendant = s;}

    public void setFirstName(String s) {firstName = s;}

    public void setLastName(String s) {lastName = s;}

    public void setGender(String s) {gender = s;}

    public void setFather(String s) {father = s;}

    public void setMother(String s) {mother = s;}

    public void setSpouse(String s) {spouse = s;}
}
