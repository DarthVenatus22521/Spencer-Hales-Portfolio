package com.example.familymapclient.UI;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.familymapclient.R;
import com.example.familymapclient.model.Model;

public class MainActivity extends AppCompatActivity {

    LoginFragment mLoginFragment;
    MapFragment mMapFragment;
    FragmentManager mFragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Model model = Model.getModel();
        if (model.getAuthToken() == null) {
            callLoginFragment();
        }
        else {
            callMapFragment();
        }
    }

    public void callLoginFragment() {
        mLoginFragment = new LoginFragment();
        mFragmentManager = this.getSupportFragmentManager();
        mFragmentManager.beginTransaction().add(R.id.main, mLoginFragment).commit();
    }

    public void callMapFragment() {
        mMapFragment = new MapFragment();
        mFragmentManager = this.getSupportFragmentManager();
        mFragmentManager.beginTransaction().add(R.id.main, mMapFragment).commit();
    }
}
