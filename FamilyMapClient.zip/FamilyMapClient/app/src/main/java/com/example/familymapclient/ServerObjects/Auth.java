package com.example.familymapclient.ServerObjects;

/**
* Model class for Auth objects
*/
public class Auth {

    String username;
    String authToken;
    String timeout;
    String personID;

    public Auth(String token, String user, String time, String id) {
        username = user;
        authToken = token;
        timeout = time;
        personID = id;
    }

    public String getUser() {return username;}
    
    public String getAuthToken() {return authToken;}

    public String getTimeout() {return timeout;}

    public String getPersonID() {return personID;}

    public void setUser(String user) {username = user;}
    
    public void setAuthToken(String token) {authToken = token;}

    public void setTimeout(String time) {timeout = time;}

    public void setPersonID(String id) {personID = id;}

    @Override 
	public boolean equals(Object o) {  
            if (o == null) {
                return false;
            }
            if (o.getClass() != this.getClass()) {
                return false;
            }
            else {
                Auth obj = (Auth) o;
                if (!obj.getUser().equals(this.getUser())) {
                    return false;
                }
                if (!obj.getAuthToken().equals(this.getAuthToken())) {
                    return false;
                }
                if (!obj.getTimeout().equals(this.getTimeout())) {
                    return false;
                }
                if (!obj.getPersonID().equals(this.getPersonID())) {
                    return false;
                }
            }
            return true;
        }
}
