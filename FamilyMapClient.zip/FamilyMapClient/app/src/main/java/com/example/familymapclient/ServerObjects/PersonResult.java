package com.example.familymapclient.ServerObjects;

import java.util.*;
import java.lang.*;

public class PersonResult {
    Set<Person> people;

    public PersonResult() {
        people = new HashSet<Person>();
    }

    public void addPerson(Person p) {
        if (p != null) {
            people.add(p);   
        }    
    }

    public String getPersons() {
        StringBuilder sb = new StringBuilder();
        for (Person p : people) {
            sb.append(getPersonInfo(p) + "\n");
        }
        return sb.toString();
    }

    private String getPersonInfo(Person p) {
        String info = "descendant: " + p.getDescendant() + "\npersonID: " + p.getPerson() + 
                      "\nfirstName: " + p.getFirstName() + "\nlastName: " + p.getLastName() + "\ngender: " + p.getGender();
        return info;
    }

    public Set<Person> getPeople() {
        return people;
    }

    public int getNumPeople() {
        return people.size();
    }
}
