package com.example.familymapclient.UI;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.familymapclient.R;
import com.example.familymapclient.Server.ServerProxy;
import com.example.familymapclient.ServerObjects.Event;
import com.example.familymapclient.ServerObjects.LoginRequest;
import com.example.familymapclient.ServerObjects.LoginResult;
import com.example.familymapclient.ServerObjects.Person;
import com.example.familymapclient.ServerObjects.RegisterRequest;
import com.example.familymapclient.ServerObjects.RegisterResult;
import com.example.familymapclient.model.Model;
import com.google.android.gms.common.SignInButton;

import java.util.ArrayList;

public class LoginFragment extends Fragment {

    private EditText mServerHostField;
    private EditText mServerPortField;
    private EditText mUserNameField;
    private EditText mPasswordField;
    private EditText mFirstNameField;
    private EditText mLastNameField;
    private EditText mEmailField;
    private RadioGroup mGenderGroup;

    private Button mSignInButton;
    private Button mRegisterButton;

    private String mServerHost;
    private String mServerPort;
    private String mUserName;
    private String mPassword;
    private String mFirstName;
    private String mLastName;
    private String mEmail;
    private String mGender;

    private Model mModel;

    public LoginFragment() {
        // Required empty public constructor
    }


    public static LoginFragment newInstance() {
        LoginFragment fragment = new LoginFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
        mModel = Model.getModel();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        mServerHostField = (EditText) view.findViewById(R.id.server_host_edittext);
        mServerPortField = (EditText) view.findViewById(R.id.server_port_edittext);
        mUserNameField = (EditText) view.findViewById(R.id.user_name_edittext);
        mPasswordField = (EditText) view.findViewById(R.id.password_edittext);
        mFirstNameField = (EditText) view.findViewById(R.id.first_name_editttext);
        mLastNameField = (EditText) view.findViewById(R.id.last_name_edittext);
        mEmailField = (EditText) view.findViewById(R.id.email_edittext);
        mGenderGroup = (RadioGroup) view.findViewById(R.id.gender_radio_group);
        mSignInButton = (Button) view.findViewById(R.id.sign_in_button);
        mRegisterButton = (Button) view.findViewById(R.id.register_button);

        updateButtons();

        mServerHostField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mServerHost = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateButtons();
            }
        });

        mServerPortField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mServerPort = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateButtons();
            }
        });

        mUserNameField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mUserName = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateButtons();
            }
        });

        mPasswordField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mPassword = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateButtons();
            }
        });

        mFirstNameField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mFirstName = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateButtons();
            }
        });

        mLastNameField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mLastName = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateButtons();
            }
        });

        mEmailField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mEmail = s.toString();
            }

            @Override
            public void afterTextChanged(Editable s) {
                updateButtons();
            }
        });

        mGenderGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int genderChecked = group.getCheckedRadioButtonId();
                switch (genderChecked) {
                    case R.id.male_radio_button:
                        mGender = "m";
                        break;
                    case R.id.female_radio_button:
                        mGender = "f";
                        break;
                }
                updateButtons();
            }
        });

        mSignInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickedSignIn();
            }
        });

        mRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickedRegister();
            }
        });

        return view;
    }

    private void updateButtons() {
        checkLogin();
        checkRegister();
    }

    private void checkLogin() {
        if (!canLogin()) {
            mSignInButton.setEnabled(false);
            return;
        }
        mSignInButton.setEnabled(true);
    }

    private void checkRegister() {
        if (!canRegister()) {
            mRegisterButton.setEnabled(false);
            return;
        }
        mRegisterButton.setEnabled(true);
    }

    private boolean canLogin() {
        if (isEmpty(mServerHostField) || isEmpty(mServerPortField) || isEmpty(mUserNameField) || isEmpty(mPasswordField)) {
            return false;
        }
        return true;
    }

    private boolean canRegister() {
        if (!canLogin() || isEmpty(mFirstNameField) || isEmpty(mLastNameField) || isEmpty(mEmailField) || mGenderGroup.getCheckedRadioButtonId() == -1) {
            return false;
        }
        return true;
    }

    private boolean isEmpty(EditText editText) {
        if (editText.getText().toString().trim().length() > 0) {
            return false;
        }
        return true;
    }

    private void clickedSignIn() {
        SignInTask login = new SignInTask();
        login.execute();
    }

    private void clickedRegister() {
        RegisterTask register = new RegisterTask();
        register.execute();
    }

    private void getFamilyData() {
        FamilyDataTask familyDataTask = new FamilyDataTask();
        familyDataTask.execute();
    }

    public class SignInTask extends AsyncTask<Void, String, LoginResult> {
        protected LoginResult doInBackground(Void... voids) {
            LoginRequest loginRequest = new LoginRequest(mUserName, mPassword);
            publishProgress("Logging in " + mUserName);
            ServerProxy serverProxy = new ServerProxy();
            LoginResult loginResult = serverProxy.login(mServerHost, mServerPort, loginRequest);
            return loginResult;
        }

        protected void onProgressUpdate(String... updateMessage) {
            Toast.makeText(getContext(), updateMessage[0], Toast.LENGTH_SHORT).show();
        }

        protected void onPostExecute(LoginResult loginResult) {
            if (loginResult != null && loginResult.getAuthToken() != null) {
                mModel.setAuthToken(loginResult.getAuthToken());
                mModel.setRootPersonID(loginResult.getPersonID());
                mModel.setServerHost(mServerHost);
                mModel.setServerPort(mServerPort);
                getFamilyData();
            }
            else {
                Toast.makeText(getContext(), "Invalid Login", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public class RegisterTask extends AsyncTask<Void, String, RegisterResult> {
        protected RegisterResult doInBackground(Void... voids) {
            RegisterRequest registerRequest = new RegisterRequest(mUserName, mPassword, mEmail, mFirstName, mLastName, mGender);
//            publishProgress("Registering " + mUserName);
            ServerProxy serverProxy = new ServerProxy();
            RegisterResult registerResult = serverProxy.register(mServerHost, mServerPort, registerRequest);
            return registerResult;
        }

        protected void onProgressUpdate(String... updateMessage) {
            Toast.makeText(getContext(), updateMessage[0], Toast.LENGTH_SHORT).show();
        }

        protected void onPostExecute(RegisterResult registerResult) {
            if (registerResult == null) {
                Toast.makeText(getContext(), "Null Result", Toast.LENGTH_SHORT).show();
            }
            if (registerResult != null && registerResult.getAuthToken() != null) {
                mModel.setAuthToken(registerResult.getAuthToken());
                mModel.setRootPersonID(registerResult.getPersonID());
                mModel.setServerHost(mServerHost);
                mModel.setServerPort(mServerPort);
                mModel.setFirstName(mFirstName);
                mModel.setLastName(mLastName);
                getFamilyData();
            }
            else {
                Toast.makeText(getContext(), "Invalid Register", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public class FamilyDataTask extends AsyncTask<Void, String, Void> {
        protected Void doInBackground(Void... v) {
            ServerProxy serverProxy = new ServerProxy();
            serverProxy.getFamilyData(mServerHost, mServerPort);
            return null;
        }

        protected void onProgressUpdate(String... updateMessage) {
            Toast.makeText(getContext(), updateMessage[0], Toast.LENGTH_SHORT).show();
        }

        protected void onPostExecute(Void v) {
            Person rootPerson = mModel.getPersonByID(mModel.getRootPersonID());
            if (rootPerson == null) {
                Log.v("FamilyDataPostTask","Error getting rootPersonID");
                return;
            }
            Toast.makeText(getContext(), "First Name: " + rootPerson.getFirstName() +
                    "\nLast Name: " + rootPerson.getLastName(), Toast.LENGTH_SHORT).show();
            //getActivity().onBackPressed();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
