package com.example.familymapclient.model;

import com.example.familymapclient.ServerObjects.Event;
import com.example.familymapclient.ServerObjects.Person;

import java.util.ArrayList;
import java.util.Set;

public class Model {

    static Model mModel;
    String mAuthToken;
    String mRootPersonID;
    String mServerHost;
    String mServerPort;
    String mFirstName;
    String mLastName;

    Set<Person> mPersonArrayList;
    Set<Event> mEventArrayList;

    Model() {}

   public static Model getModel() {
       if (mModel == null) {
           mModel = new Model();
       }
       return mModel;
   }

   public Person getPersonByID(String id) {
        for (Person p : getPersonSetList()) {
            if (p.getPerson().equals(id)) {
                return p;
            }
        }
        return null;
   }

    public static void setmModel(Model mModel) {
        Model.mModel = mModel;
    }

    public String getAuthToken() {
        return mAuthToken;
    }

    public void setAuthToken(String authToken) {
        mAuthToken = authToken;
    }

    public String getRootPersonID() {
        return mRootPersonID;
    }

    public void setRootPersonID(String rootPersonID) {
        mRootPersonID = rootPersonID;
    }

    public String getServerHost() {
        return mServerHost;
    }

    public void setServerHost(String serverHost) {
        mServerHost = serverHost;
    }

    public String getServerPort() {
        return mServerPort;
    }

    public void setServerPort(String serverPost) {
        mServerPort = serverPost;
    }

    public String getFirstName() {
        return mFirstName;
    }

    public void setFirstName(String firstName) {
        mFirstName = firstName;
    }

    public String getLastName() {
        return mLastName;
    }

    public void setLastName(String lastName) {
        mLastName = lastName;
    }

    public Set<Person> getPersonSetList() {
        return mPersonArrayList;
    }

    public void setPersonSetList(Set<Person> personArrayList) {
        mPersonArrayList = personArrayList;
    }

    public Set<Event> getEventSetList() {
        return mEventArrayList;
    }

    public void setEventSetList(Set<Event> eventArrayList) {
        mEventArrayList = eventArrayList;
    }
}
