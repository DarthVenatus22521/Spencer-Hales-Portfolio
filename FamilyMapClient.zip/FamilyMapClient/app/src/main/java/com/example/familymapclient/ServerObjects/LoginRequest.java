package com.example.familymapclient.ServerObjects;

/**
 *Class to contain information needed to start the login service
 */
public class LoginRequest {

    String userName;
    String password;

    public LoginRequest(String user, String pass) {
        userName = user;
        password = pass;
    }

    public String getUsername() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String user) {
        userName = user;
    }

    public void setPassword(String pass) {
        password = pass;
    }

    /**
     *Method to return the needed information for Login
     */
    /*public String toString() {
        return null;
    }*/
}
