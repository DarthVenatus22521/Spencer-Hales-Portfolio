package com.example.familymapclient.Server;

import java.net.URL;
import com.example.familymapclient.ServerObjects.*;
import com.example.familymapclient.model.Model;
import com.google.gson.*;

public class ServerProxy {
    public LoginResult login(String serverHost, String serverPort, LoginRequest loginRequest) {
        try {
            HttpClient httpClient = new HttpClient();
            Gson gson = new Gson();
            URL url = new URL("https://" + serverHost + ":" + serverPort + "/user/login");
            StringBuilder sb = new StringBuilder();
            sb.append("{\n\"userName\":\"");
            sb.append(loginRequest.getUsername());
            sb.append("\",\n\"password\":\"");
            sb.append(loginRequest.getPassword());
            String request = sb.toString();
            String response = httpClient.postResponse(url, request);
            return gson.fromJson(response, LoginResult.class);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public RegisterResult register(String serverHost, String serverPort, RegisterRequest registerRequest) {
        try {
            HttpClient httpClient = new HttpClient();
            Gson gson = new Gson();
            URL url = new URL("https://" + serverHost + ":" + serverPort + "/user/register");
            StringBuilder sb = new StringBuilder();
            sb.append("{\n\"userName\":\"");
            sb.append(registerRequest.getUsername());
            sb.append("\",\n\"password\":\"");
            sb.append(registerRequest.getPassword());
            sb.append("\",\n\"email\":\"");
            sb.append(registerRequest.getEmail());
            sb.append("\",\n\"firstName\":\"");
            sb.append(registerRequest.getFirstName());
            sb.append("\",\n\"lastName\":\"");
            sb.append(registerRequest.getLastName());
            sb.append("\",\n\"gender\":\"");
            sb.append(registerRequest.getGender());
            String request = sb.toString();
            String response = httpClient.postResponse(url, request);
            return gson.fromJson(response, RegisterResult.class);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void getFamilyData(String serverHost, String serverPort) {
        try {
            Model model = Model.getModel();
            HttpClient httpClient = new HttpClient();
            Gson gson = new Gson();
            URL personurl = new URL("https://" + serverHost + ":" + serverPort + "/user/event");
            String personResponse = httpClient.getResponse(personurl, model.getAuthToken());
            URL eventurl = new URL("https://" + serverHost + ":" + serverPort + "/user/event");
            String eventResponse = httpClient.getResponse(eventurl, model.getAuthToken());
            PersonResult personResult = gson.fromJson(personResponse, PersonResult.class);
            EventResult eventResult = gson.fromJson(eventResponse, EventResult.class);

            model.setEventSetList(eventResult.getEventSet());
            model.setPersonSetList(personResult.getPeople());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
