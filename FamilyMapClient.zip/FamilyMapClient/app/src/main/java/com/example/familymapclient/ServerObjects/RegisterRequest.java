package com.example.familymapclient.ServerObjects;

/**
 *Class to contain information needed to start the registration service
 */
public class RegisterRequest {

    String userName;
    String password;
    String email;
    String firstName;
    String lastName;
    String gender;

    public RegisterRequest(String user, String pass, String mail, String first, String last, String gen) {
        userName = user;
        password = pass;
        email = mail;
        firstName = first;
        lastName = last;
        gender = gen;
    }

    public String getUsername() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }
    
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setUsername(String s) {
        userName = s;
    }

    public void setPassword(String s) {
        password = s;
    }

    public void setEmail(String s) {
        email = s;
    }
    
    public void setFirstName(String s) {
        firstName = s;
    }

    public void setLastName(String s) {
        lastName = s;
    }

    public void setGender(String s) {
        gender = s;
    }
}
